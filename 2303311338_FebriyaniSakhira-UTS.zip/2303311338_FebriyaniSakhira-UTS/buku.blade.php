<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Manajemen Buku</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <div class="max-w-6xl mx-auto bg-white p-6 rounded shadow">
    <!-- Header -->
    <div class="flex justify-between items-center mb-4">
      <h1 class="text-2xl font-bold">Manajemen Buku</h1>
      <a href="{{ route('buku.create') }}" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">+ Tambah Buku</a>
    </div>

    @php
      $editMode = request()->has('edit');
      $editBuku = $editMode ? $buku->firstWhere('id', request('edit')) : null;
    @endphp

    <!-- Form Buku -->
    @if ($editMode && $editBuku)
      <form action="{{ route('buku.update', $editBuku->id) }}" method="POST" class="mb-6" id="form-buku">
        @csrf
        @method('PUT')
        <h2 class="text-xl font-semibold mb-2">Edit Buku</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <input type="text" name="judul" value="{{ old('judul', $editBuku->judul) }}" placeholder="Judul Buku" class="border px-3 py-2 rounded" required>
          <input type="text" name="pengarang" value="{{ old('pengarang', $editBuku->pengarang) }}" placeholder="Pengarang" class="border px-3 py-2 rounded" required>
          <input type="number" name="tahun" value="{{ old('tahun', $editBuku->tahun) }}" placeholder="Tahun Terbit" class="border px-3 py-2 rounded" required>
          <input type="text" name="penerbit" value="{{ old('penerbit', $editBuku->penerbit) }}" placeholder="Penerbit" class="border px-3 py-2 rounded" required>
          <input type="text" name="kategori" value="{{ old('kategori', $editBuku->kategori) }}" placeholder="Kategori" class="border px-3 py-2 rounded md:col-span-2" required>
        </div>
        <button type="submit" class="bg-yellow-600 text-white px-4 py-2 rounded hover:bg-yellow-700">Update</button>
        <a href="{{ route('buku.index') }}" class="ml-2 text-sm text-blue-600 hover:underline">Batal</a>
      </form>
    @else
      <form action="{{ route('buku.store') }}" method="POST" class="mb-6" id="form-buku">
        @csrf
        <h2 class="text-xl font-semibold mb-2">Form Buku</h2>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <input type="text" name="judul" placeholder="Judul Buku" class="border px-3 py-2 rounded" required>
          <input type="text" name="pengarang" placeholder="Pengarang" class="border px-3 py-2 rounded" required>
          <input type="number" name="tahun" placeholder="Tahun Terbit" class="border px-3 py-2 rounded" required>
          <input type="text" name="penerbit" placeholder="Penerbit" class="border px-3 py-2 rounded" required>
          <input type="text" name="kategori" placeholder="Kategori" class="border px-3 py-2 rounded md:col-span-2" required>
        </div>
        <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">Simpan</button>
      </form>
    @endif

    <!-- Tabel Daftar Buku -->
    <div>
      <h2 class="text-xl font-semibold mb-2">Daftar Buku</h2>
      <div class="overflow-x-auto">
        <table class="w-full text-left border">
          <thead class="bg-gray-200">
            <tr>
              <th class="p-2">JUDUL</th>
              <th class="p-2">PENGARANG</th>
              <th class="p-2">TAHUN</th>
              <th class="p-2">PENERBIT</th>
              <th class="p-2">KATEGORI</th>
              <th class="p-2">AKSI</th>
            </tr>
          </thead>
          <tbody>
            @forelse ($buku as $item)
              <tr class="border-t">
                <td class="p-2">{{ $item->judul }}</td>
                <td class="p-2">{{ $item->pengarang }}</td>
                <td class="p-2">{{ $item->tahun }}</td>
                <td class="p-2">{{ $item->penerbit }}</td>
                <td class="p-2">{{ $item->kategori }}</td>
                <td class="p-2 space-x-2">
                  <form action="{{ route('buku.destroy', $item->id) }}" method="POST" class="inline">
                    @csrf
                    @method('DELETE')
                    <button class="bg-red-600 px-3 py-1 rounded text-white hover:bg-red-700">Hapus</button>
                  </form>
                  <a href="{{ route('buku.index') . '?edit=' . $item->id }}" class="bg-yellow-500 px-3 py-1 rounded text-white hover:bg-yellow-600">Edit</a>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="6" class="text-center p-4">Belum ada buku.</td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>
    </div>

    <!-- Pagination Placeholder -->
    <div class="flex justify-between items-center mt-4 text-sm text-gray-600">
      <span>Menampilkan {{ count($buku) }} buku</span>
    </div>
  </div>
</body>
</html>
